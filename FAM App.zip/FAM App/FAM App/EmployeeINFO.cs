﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FAM_App
{
    internal class EmployeeINFO
    {
        public static int ID_EmployeeINFO;
    }
}
